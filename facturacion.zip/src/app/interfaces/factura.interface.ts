export interface Factura {
  id: number;
  cliente: string;
  fecha: string;
  producto: string;
  total: number;
}